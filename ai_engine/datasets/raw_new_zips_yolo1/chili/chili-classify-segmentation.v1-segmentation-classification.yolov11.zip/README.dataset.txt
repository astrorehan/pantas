# chili-classify-segmentation > segmentation-classification
https://universe.roboflow.com/mvi-ilc1r/chili-classify-segmentation

Provided by a Roboflow user
License: CC BY 4.0

